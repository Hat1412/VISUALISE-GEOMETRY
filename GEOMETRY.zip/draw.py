from turtle import *
from tkinter import *
from PIL import Image,ImageTk
import turtle,pyautogui
from tkinter import colorchooser,filedialog

root = Tk()
root.config(bg= "white")
root.title("DRAWING BOARD")
root.attributes("-topmost", True)

s = Screen()
t = Turtle()
t.speed(0)
w = 1

t.width(4)

def cc0():
    s.colormode(255)
    color = colorchooser.askcolor()
    try:
        r = int(color[0][0])
        g = int(color[0][1])
        b = int(color[0][2])
        t.pencolor(r,g,b)
    except TypeError:
        pass

def clear0():
    t.clear()
    t.penup()
    t.home()
    t.pendown()
  
def dt():
    global w
    w-=1
    if(w < 0):
        
        
        w = 0
    t.width(w)
    t.shapesize(1,1,4)

def close_all():
    try:
        s.bye()
        root.destroy()
    except:
        root.destroy()

def it():
    global w
    w+=1
    t.width(w)
    t.shapesize(1,1,4)

def dragging(x, y):
    t.ondrag(None)
    t.setheading(t.towards(x, y))
    t.goto(x, y)
    t.ondrag(dragging)

def ts ():
    ts = turtle.getscreen()
    file_path = filedialog.asksaveasfilename(defaultextension=('.eps'))
    ts.getcanvas().postscript(file=fr"{file_path}")

image = Image.open(r'color.png')
image = image.resize((50,50), Image.ANTIALIAS)
color0 = ImageTk.PhotoImage(image)

image = Image.open(r'save0.png')
image = image.resize((50,50), Image.ANTIALIAS)
save0 = ImageTk.PhotoImage(image)

image = Image.open(r'cls.png')
image = image.resize((50,50), Image.ANTIALIAS)
cls = ImageTk.PhotoImage(image)

image = Image.open(r'close.png')
image = image.resize((50,50), Image.ANTIALIAS)
close = ImageTk.PhotoImage(image)

image = Image.open(r'+.png')
image = image.resize((50,50), Image.ANTIALIAS)
pl = ImageTk.PhotoImage(image)

image = Image.open(r'-.png')
image = image.resize((50,50), Image.ANTIALIAS)
mi = ImageTk.PhotoImage(image)

def k(x,y):
    if(t.isdown() == False):
        t.pendown()
        
    else:
        t.penup()
    
def j(x,y):
    t.goto(x,y)

Button(root,image = color0,command=cc0,bg = "white").grid(row = 0,column = 0,padx = 20,pady= 20)
Button(root,command = ts,image = save0,bg = "white").grid(row = 0,column = 1,padx = 20,pady = 20)
Button(root,image = cls,command = clear0,bg = "white").grid(row = 1,column = 0,padx = 20,pady = 20)
Button(root,image = close,command = close_all,bg = "white").grid(row = 1,column = 1,padx = 20,pady = 20)
Button(root,command = it,image = pl,bg = "white").grid(row = 2,column = 0,padx = 20,pady = 20)
Button(root,command = dt,image = mi,bg = "white").grid(row = 2,column = 1,padx = 20,pady = 20)



def main():  
    turtle.listen()
    t.ondrag(dragging)
    turtle.onscreenclick(j,1)
    turtle.onscreenclick(k,3)
    s.mainloop()

main()
root.mainloop()
