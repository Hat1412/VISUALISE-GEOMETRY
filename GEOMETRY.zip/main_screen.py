#IMPORT LIBRARIES AND SET UP SCREEN
import turtle,random,os
from turtle import *
import pygame

t = Turtle()
s = Screen()  
pygame.init()                 
pygame.mixer.init()
t.speed(6)
s.setup(width=1.0, height=1.0, startx=None, starty=None)
t.clear()
t.penup()

pygame.mixer.music.load(r"tetris.mp3")
pygame.mixer.music.play(loops = 0)
def triangle():
     t.pendown()
     for i in range(3): 
                t.color(random.choice(["red","blue","green","orange","purple"]))
                t.forward(100) 
                t.left(120) 
                t.forward(100)
#CREATE BASE TRIANGES
t.goto(-650,-350)
triangle()
for i in range(5):
    t.penup() 
    t.fd(250)
    triangle()

#CREATE TOP TRIANGLES
t.penup()
t.goto(-650,200)
triangle()

for i in range(5):
    t.penup() 
    t.fd(250)
    triangle()

#WRITE TEXT

t.penup()
t.goto(-500,0)
t.pendown()
t.color("black")
t.write("GEOMETRY WITH PYTHON",font = ("Franklin Gothic Medium",59),align = "left")
t.penup()
t.goto(-25,-50)
t.write("-CLICK TO START",font = ("Franklin Gothic Medium",23),align = "left")
t.color("white")

def move(x,y):
    s.bye()
    os.startfile(r"play_store.py")
#MAINLOOP
s.onclick(move)
turtle.mainloop()