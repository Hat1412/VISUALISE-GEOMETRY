from turtle import *
import turtle
import webbrowser,random
from tkinter import *

root = Tk()
root.columnconfigure(0, weight=1)
root.rowconfigure((0,1,2,3,4), weight=1)
#root.rowconfigure(1, weight=2)
 


col = ["red","blue","pink","grey"]

def vid():
    webbrowser.open("https://www.techwithtim.net/tutorials/python-module-walk-throughs/")
def read():
    webbrowser.open("https://www.instructables.com/ART-WITH-PYTHON/")
def vid_tk():
    webbrowser.open("https://www.youtube.com/watch?v=yQSEXcf6s2I&list=PLCC34OHNcOtoC6GglhF3ncJ5rLwQrLGnV&index=2")

def live():
    t = Turtle()
    s = Screen()
    safe = Tk()
    t.speed("fastest")
    s.setup(width = 1.0, height = 1.0)
    
    def btn1():
        t.goto(0,-440)
        t.pendown()
        t.clear()
        root.attributes('-alpha', 0)
        safe.attributes('-alpha',0)   
        for i in range(400):
            t.color(random.choice(["red","blue","green","black","orange"]))
            t.circle(i*4)
            if i%20 == 0:
                turtle.update()
        root.attributes('-alpha', 1)
        safe.attributes('-alpha',1)   
        

    def btn2():
        root.attributes('-alpha', 0)
        safe.attributes('-alpha',0)   
        t.home()
        t.clear()
        turtle.tracer(0,0)
        for i in range(480):
            t.color(random.choice(["red","blue","black","orange"]))
            t.circle(i+5)
            t.right(90)
            if i%10 == 0:
                turtle.update()
        root.attributes('-alpha', 1)
        safe.attributes('-alpha',1)   
        
    def btn3():
        j = 500
        t.home()
        t.clear()
        turtle.tracer(0,0)
        root.attributes('-alpha', 0)
        safe.attributes('-alpha',0)   
        while j != 0:
            t.fillcolor(random.choice(["red","blue","green","orange"]))
            t.begin_fill()
            t.circle(j)
            t.right(90)
            t.end_fill()
            if j%20 == 0:
                turtle.update()
            j-=1
        root.attributes('-alpha', 1)
        safe.attributes('-alpha',1)   
        
    def btn4():
        root.attributes('-alpha', 0)
        safe.attributes('-alpha',0)   
        turtle.tracer(0,0)
        t.goto(-400*2,400*2)
        t.clear()
        for i in range(800):
                t.color(random.choice(["red","blue","green","orange","purple","grey"]))
                for _ in range(4):
                    t.fd(i*2)
                    t.right(90)
                if i%60 == 0:
                    turtle.update()
        root.attributes('-alpha',1)
        safe.attributes('-alpha',1)   
    
    Button(safe,text = "I",font = ("Franklin Gothic Medium",30),command = btn1).grid(row = 0,column = 0,padx = 20,pady = 20)
    Button(safe,text = "II",font = ("Franklin Gothic Medium",30),command = btn2).grid(row = 0,column = 1,padx = 20,pady = 20)
    Button(safe,text = "III",font = ("Franklin Gothic Medium",30),command = btn3).grid(row = 0,column = 2,padx = 20,pady = 20)
    Button(safe,text = "IV",font = ("Franklin Gothic Medium",30),command = btn4).grid(row = 0,column = 3,padx = 20,pady = 20)
    
    s.exitonclick()    
Button(root,text="READ AN INSTRUCTABLE",font = ("Franklin Gothic Medium",30),command = read,bg = col[0]).grid(row = 1,column = 0,sticky="NSEW")
Button(root,text="HELP WITH TURTLE",font = ("Franklin Gothic Medium",30),command = vid,bg = col[1]).grid(row = 0,column = 0,sticky = "NSEW")
Button(root,text="HELP WITH TKINTER",font = ("Franklin Gothic Medium",30),bg = col[2],command = vid_tk).grid(row = 2,column = 0,sticky = "NSEW")
Button(root,text="WATCH TURTLE LIVE",command = live,font = ("Franklin Gothic Mediumc",30),bg = col[3]).grid(row = 3,column = 0,sticky = "NSEW")


try:
    root.mainloop()
    turtle.mainloop()
except turtle.Terminator:
    pass
    