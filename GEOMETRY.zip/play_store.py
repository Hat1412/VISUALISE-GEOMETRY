from tkinter import *
from PIL import Image,ImageTk
import random,os

root = Tk()
root.configure(bg = "white")
root.state('zoomed')
root.title("HOME PAGE")
colors = ["orange","green","cyan"]

image = Image.open(r'output.png')
image = image.resize((1600,800), Image.ANTIALIAS)
filename = ImageTk.PhotoImage(image)

background_label = Label(root, image=filename)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

image = Image.open(r'bg0.png')
#image = image.resize((100,150), Image.ANTIALIAS)
bg_photo = ImageTk.PhotoImage(image)

Label(root,image = bg_photo,font = ("Franklin Gothic Medium",30),borderwidth = 0).pack(pady = 40)

def draw():
    os.system(r"draw.py")
def poly():
    os.system(r"polygon.py")
def con():
    os.system(r"cons.py")
def info():
    os.system(r"more_on_turtle.py")


image = Image.open(r'draw0.png')
#image = image.resize((100,150), Image.ANTIALIAS)
r_photo = ImageTk.PhotoImage(image)

image = Image.open(r'polygon0.png')
#image = image.resize((200,170), Image.ANTIALIAS)
p_photo = ImageTk.PhotoImage(image)

image = Image.open(r'learn0.png')
#image = image.resize((200,150), Image.ANTIALIAS)
s_photo = ImageTk.PhotoImage(image)

image = Image.open(r'cons0.png')
#image = image.resize((200,150), Image.ANTIALIAS)
l_photo = ImageTk.PhotoImage(image)

Button(root,command = draw,image = r_photo,borderwidth = 0,highlightthickness=0).pack()
Button(root,command = poly,image = p_photo,text = "POLYGONS",borderwidth = 0,highlightthickness=0).pack()
Button(root,command = info,image = s_photo,text = "LEARN MORE",borderwidth = 0,highlightthickness=0).pack()
Button(root,command = con,image = l_photo,text = "LEARN MORE",borderwidth = 0,highlightthickness=0).pack()
root.mainloop()
