from turtle import *
import turtle,math
from tkinter import *

root = Tk()

root.config(bg = "cyan")
#root.geometry("100x450")
s = Screen()
t = turtle
def close_all():
    try:
        root.destroy()
        s.bye()
    except:
        root.destroy()
s.setup(width = 1.0, height = 1.0)
root.attributes("-topmost", True)
def close():
    s.bye()
    root.destroy()

def polygon0():
    t.reset()
    

    try:
        sides = int(side.get())
    except ValueError:
        sides = int(eval(side.get()))

    root.attributes('-alpha', 0)

    for i in range(sides):
        try:
            t.fd(int(l.get()))
            t.left(int(360/int(side.get())))
        except ValueError:
            t.fd((int(eval(l.get()))))
            t.left(int(360/int(eval(side.get()))))
       
    t.home()
    
    root.attributes('-alpha', 1)
    area.config(text = f"Area = {round((int(side.get()) * (int(l.get()) ** 2) / (4 * math.tan(math.pi / int(side.get())))),2)} square units")
    perimeter.config(text = f"Perimeter = {int(int(l.get())*int(side.get()))} units ;")




f = Frame(root,bg = "cyan")
f.pack()
Label(f,text = "Enter length:",bg = "cyan",font = ("Franklin Gothic Medium",23)).grid(row = 0,column = 0)
l = Entry(f,font = ("Franklin Gothic Medium",23))
l.grid(row=0,column=1)

Label(f,text = "Enter number of sides:",font = ("Franklin Gothic Medium",23),bg = "cyan").grid(row = 1,column = 0)
side = Entry(f,font = ("Franklin Gothic Medium",23))
side.grid(row = 1,column = 1)

Button(root,text = "Draw a Polygon",command = polygon0,font = ("Franklin Gothic Medium",23)).pack()

area = Label(root,font = ("Franklin Gothic Medium",23))
area.pack(side = "right")

perimeter = Label(root,font = ("Franklin Gothic Medium",23))
perimeter.pack(side = "left")



turtle.mainloop()
root.mainloop()
